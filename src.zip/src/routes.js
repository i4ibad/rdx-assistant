// Central mapping between internal page ids and real URL paths.
// Keeping this in one place means Sidebar, Topbar, CommandPalette, and every
// page's `navigate(id)` call stay decoupled from the actual route strings.
export const pageRoutes = {
  overview: '/',
  integrations: '/integrations',
  knowledge: '/knowledge-base',
  widget: '/widget',
  conversations: '/conversations',
  analytics: '/analytics',
  team: '/team',
  settings: '/settings',
  billing: '/billing'
}

export const pathToPage = Object.fromEntries(
  Object.entries(pageRoutes).map(([pageId, path]) => [path, pageId])
)
